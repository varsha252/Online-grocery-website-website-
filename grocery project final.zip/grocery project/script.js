function submitCheckout() {
    var fullName = document.getElementById('fullName').value;
    var email = document.getElementById('email').value;
    var address = document.getElementById('address').value;
    console.log('Full Name:', fullName);
    console.log('Email:', email);
    console.log('Address:', address);

    
}
/*sign up js*/
document.getElementById('signup-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission

    
    var firstName = document.getElementById('firstName').value.trim();
    var lastName = document.getElementById('lastName').value.trim();
    var email = document.getElementById('email').value.trim();
    var password = document.getElementById('password').value.trim();
    var confirmPassword = document.getElementById('confirmPassword').value.trim();

   
    if (firstName === '' || lastName === '' || email === '' || password === '' || confirmPassword === '') {
        alert('Please fill in all fields.');
        return;
    }

    
    if (password !== confirmPassword) {
        alert('Passwords do not match.');
        return;
    }

    alert('Signed in successfully!');
});